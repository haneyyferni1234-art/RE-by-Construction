#!/usr/bin/env python3
"""
Generate all figures for the paper from benchmark data.
Output: PDF figures in paper/figures/
"""

import json
import os
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

BASE = Path(__file__).resolve().parent.parent.parent
DATA = BASE / 'benchmark_results'
OUT = Path(__file__).resolve().parent

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 10,
    'axes.labelsize': 11,
    'axes.titlesize': 12,
    'legend.fontsize': 9,
    'figure.dpi': 150,
})

REGIME_COLORS = {
    'RE_REGIME': '#2166ac',
    'MIXED': '#f4a582',
    'OE_NOT_RE': '#b2182b',
}
REGIME_ORDER = ['RE_REGIME', 'MIXED', 'OE_NOT_RE']


def load_json(path):
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return None


# ====================================================================
# FIG 1: Phase diagram
# ====================================================================
def fig1_phase_diagram():
    raw = load_json(DATA / 'phase_diagram.json')
    if raw is None:
        print("  SKIP: phase_diagram.json")
        return
    pts = raw if isinstance(raw, list) else raw.get('data', raw)
    if isinstance(pts, dict):
        pts = list(pts.values())
    if not pts or not isinstance(pts, list):
        print("  SKIP: phase_diagram.json empty")
        return

    for sym_val, suffix in [(True, 'sym_true'), (False, 'sym_false')]:
        subset = [p for p in pts if p.get('sym', not sym_val) == sym_val]
        if not subset:
            continue
        capacities = sorted(set(p['hidden'] for p in subset))
        lambdas = sorted(set(p['lambd'] for p in subset))
        c_map = {c: i for i, c in enumerate(capacities)}
        l_map = {l: i for i, l in enumerate(lambdas)}

        grid = np.full((len(lambdas), len(capacities)), '', dtype=object)
        pgrid = np.full((len(lambdas), len(capacities)), np.nan)
        for p in subset:
            c, l = p['hidden'], p['lambd']
            reg, proc = p['regime'], p['procrustes']
            grid[l_map[l], c_map[c]] = reg
            pgrid[l_map[l], c_map[c]] = proc

        fig, ax = plt.subplots(figsize=(6, 5))
        for li in range(len(lambdas)):
            for ci in range(len(capacities)):
                reg = grid[li, ci]
                color = REGIME_COLORS.get(reg, '#ccc')
                ax.add_patch(Rectangle((ci - 0.5, li - 0.5), 1, 1,
                                       facecolor=color, edgecolor='white', linewidth=1))
                v = pgrid[li, ci]
                if not np.isnan(v):
                    c2 = 'white' if reg == 'RE_REGIME' else 'black'
                    ax.text(ci, li, f'{v:.2f}', ha='center', va='center', fontsize=7, color=c2)

        ax.set_xlabel('Capacity (hidden dim)')
        ax.set_ylabel(r'Weight decay $\lambda$')
        ax.set_title(f'Phase Diagram (sym={str(sym_val)})')
        ax.set_xticks(range(len(capacities)))
        ax.set_xticklabels([str(c) for c in capacities])
        ax.set_yticks(range(len(lambdas)))
        ax.set_yticklabels([str(l) for l in lambdas])
        for r in REGIME_ORDER:
            ax.plot([], [], 's', color=REGIME_COLORS[r], label=r, markersize=8)
        ax.legend(loc='upper right')
        fig.tight_layout()
        fig.savefig(OUT / f'phase_diagram_{suffix}.pdf', bbox_inches='tight')
        plt.close(fig)
        print(f"  -> phase_diagram_{suffix}.pdf")


# ====================================================================
# FIG 2: Attention injection ablation
# ====================================================================
def fig2_ablation():
    data = load_json(DATA / 'attention_injection_ablation.json')
    if data is None:
        print("  SKIP: attention_injection_ablation.json")
        return

    variants = ['V1_MLP', 'V2_MLP_LN', 'V3_MLP_Res', 'V4_AttnOnly', 'V5_AttnRes', 'V6_FullHybrid']
    vlabels = ['MLP', 'MLP+LN', 'MLP+Res', 'AttnOnly', 'Attn+Res', 'FullHybrid']

    # data is nested: data -> results -> list of {variant, lambd, procrustes, overlap}
    results = data
    if 'data' in results:
        results = results['data']
    if 'results' in results:
        results = results['results']
    if isinstance(results, dict):
        # data is keyed by variant
        rows = []
        for v in variants:
            vd = results.get(v, {})
            if isinstance(vd, list):
                for entry in vd:
                    entry['variant'] = v
                    rows.append(entry)
            elif isinstance(vd, dict):
                for lam, metrics in vd.items():
                    rows.append({
                        'variant': v,
                        'lambd': float(lam),
                        'procrustes': metrics.get('procrustes', 0),
                        'overlap': metrics.get('overlap', 0),
                    })
        results = rows
    if isinstance(results, list):
        rows = results
    else:
        print("  SKIP: unexpected data format")
        return

    lambdas_of_interest = [0, 0.001, 0.005, 0.01]
    x = np.arange(len(variants))
    width = 0.2

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))

    colors = [plt.cm.Blues(0.3 + 0.2 * j) for j in range(4)]
    colors_o = [plt.cm.Oranges(0.3 + 0.2 * j) for j in range(4)]

    for i, v in enumerate(variants):
        vrows = [r for r in rows if r.get('variant') == v and r.get('lambd', r.get('lambda', 0)) in lambdas_of_interest]
        vrows.sort(key=lambda r: r.get('lambd', r.get('lambda', 0)))
        for j, r in enumerate(vrows):
            lam = r.get('lambd', r.get('lambda', 0))
            p = r.get('procrustes', 0)
            o = r.get('overlap', 0)
            offset = (j - 1.5) * width
            ax1.bar(i + offset, p, width, color=colors[j],
                    label=f'$\\lambda$={lam}' if i == 0 else '')
            ax2.bar(i + offset, o, width, color=colors_o[j],
                    label=f'$\\lambda$={lam}' if i == 0 else '')

    ax1.set_xticks(x)
    ax1.set_xticklabels(vlabels, rotation=30, ha='right')
    ax1.set_ylabel('Procrustes Residual')
    ax1.set_title('Global Alignment')
    ax1.axhline(0.15, color='gray', linestyle='--', alpha=0.5)

    ax2.set_xticks(x)
    ax2.set_xticklabels(vlabels, rotation=30, ha='right')
    ax2.set_ylabel('Neighborhood Overlap')
    ax2.set_title('Local Geometry')
    ax2.axhline(0.75, color='gray', linestyle='--', alpha=0.5)

    handles, labels = ax1.get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 1.05),
               ncol=4, fontsize=9)
    fig.tight_layout()
    fig.savefig(OUT / 'ablation_bar.pdf', bbox_inches='tight')
    plt.close(fig)
    print("  -> ablation_bar.pdf")


# ====================================================================
# FIG 3: Counterfactual basis reset
# ====================================================================
def fig3_basis_reset():
    data = load_json(DATA / 'counterfactual_basis_reset.json')
    if data is None:
        print("  SKIP: counterfactual_basis_reset.json")
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5))

    agg = data.get('aggregate', {})
    reps = data.get('replicates', [])

    # Loss trajectory from first replicate
    if reps:
        rep = reps[0]
        ctrl_traj = rep.get('control', {}).get('loss_trajectory', [])
        treat_traj = rep.get('treatment', {}).get('loss_trajectory', [])
        if ctrl_traj and treat_traj:
            ax1.plot(range(len(ctrl_traj)), ctrl_traj, 'b-', label='Control', alpha=0.7)
            ax1.plot(range(len(treat_traj)), treat_traj, 'r-', label='Treatment', alpha=0.7)
            ax1.axvline(x=200, color='gray', linestyle='--', alpha=0.5)
            ax1.text(205, max(max(ctrl_traj), max(treat_traj)) * 0.95,
                     'Rotation', fontsize=8, color='gray')
            ax1.set_xlabel('Training Step')
            ax1.set_ylabel('Loss')
            ax1.set_title('Loss Trajectories (Seed 0)')
            ax1.legend()

    # Bar chart from aggregate
    labels = ['Pre-Rotate', 'Post-Rotate', 'Final']
    ctrl_bars = [
        agg.get('avg_control_final_procrustes', 0.1239),
        agg.get('avg_control_final_procrustes', 0.1239),
        agg.get('avg_control_final_procrustes', 0.1239),
    ]
    treat_bars = [
        agg.get('avg_treat_pre_rotate_procrustes', 0.251),
        agg.get('avg_treat_post_rotate_procrustes', 0.8455),
        agg.get('avg_treat_final_procrustes', 0.1281),
    ]

    width = 0.3
    x = np.arange(3)
    ax2.bar(x - width / 2, ctrl_bars, width, label='Control', color='#4393c3', alpha=0.7)
    ax2.bar(x + width / 2, treat_bars, width, label='Treatment', color='#d6604d', alpha=0.7)
    ax2.set_xticks(x)
    ax2.set_xticklabels(labels)
    ax2.set_ylabel('Procrustes Residual')
    ax2.set_title('Regime at Checkpoints (3-seed avg)')
    ax2.axhline(0.15, color='gray', linestyle='--', alpha=0.5, label='RE threshold')
    ax2.legend()

    # Regime annotations
    pre_regimes = agg.get('pre_rotate_regimes', [])
    post_regimes = agg.get('post_rotate_immediate_regimes', [])
    final_regimes = agg.get('final_regimes', [])
    for xi, regimes in enumerate([pre_regimes, post_regimes, final_regimes]):
        counts = {r: regimes.count(r) for r in set(regimes)}
        txt = ', '.join(f'{r.split("_")[0]}:{c}' for r, c in counts.items())
        ax2.text(xi, max(ctrl_bars[xi], treat_bars[xi]) + 0.05, txt,
                 ha='center', fontsize=7, rotation=0)

    fig.tight_layout()
    fig.savefig(OUT / 'basis_reset.pdf', bbox_inches='tight')
    plt.close(fig)
    print("  -> basis_reset.pdf")


# ====================================================================
# FIG 4: Cross-architecture isomorphism
# ====================================================================
def fig4_isomorphism():
    data = load_json(DATA / 'isomorphism_results.json')
    if data is None:
        print("  SKIP: isomorphism_results.json")
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5))

    # Left: regime counts per arch
    arch_data = {}
    for arch in ['mlp', 'hybrid', 'transformer']:
        d = load_json(DATA / f'regime_maps_{arch}.json')
        if d and arch in d:
            rows = d[arch]
            regimes = [r['regime'] for r in rows]
            arch_data[arch] = regimes

    if arch_data:
        x = np.arange(len(arch_data))
        w = 0.25
        for i, reg in enumerate(REGIME_ORDER):
            counts = [sum(1 for r in arch_data[a] if r == reg) for a in arch_data]
            ax1.bar(x + (i - 1) * w, counts, w, label=reg, color=REGIME_COLORS[reg])
        ax1.set_xticks(x)
        ax1.set_xticklabels(list(arch_data.keys()))
        ax1.set_ylabel('Count (out of 24)')
        ax1.set_title('Regime Distribution by Architecture')
        ax1.legend()
    else:
        ax1.text(0.5, 0.5, 'No regime data available', ha='center', va='center')
        ax1.set_title('Regime Distribution (no data)')

    # Right: comparison metrics
    results = data.get('results', [])
    if results:
        labels = [r['arch_pair'].replace('_', ' ').title() for r in results]
        kappas = [r['verdict']['scores']['cohens_kappa'] for r in results]
        agreements = [r['label_test']['agreement_fraction'] for r in results]
        geo = [r['verdict']['scores']['geometric_distortion'] for r in results]

        x2 = np.arange(len(results))
        ax2.bar(x2 - 0.2, kappas, 0.2, label=r"Cohen's $\kappa$", color='#4393c3')
        ax2.bar(x2, agreements, 0.2, label='Label Agreement', color='#92c5de')
        ax2.bar(x2 + 0.2, geo, 0.2, label='Geo. Distortion', color='#d6604d')
        ax2.set_xticks(x2)
        ax2.set_xticklabels(labels, rotation=15)
        ax2.set_ylabel('Score')
        ax2.set_title('Cross-Architecture Isomorphism Tests')
        ax2.axhline(0, color='gray', linewidth=0.5)
        ax2.legend(fontsize=8)
    else:
        ax2.text(0.5, 0.5, 'No comparison data', ha='center', va='center')
        ax2.set_title('Isomorphism Tests')

    fig.tight_layout()
    fig.savefig(OUT / 'isomorphism.pdf', bbox_inches='tight')
    plt.close(fig)
    print("  -> isomorphism.pdf")


# ====================================================================
# FIG 5: RE-by-construction (hardcoded from archive data)
# ====================================================================
def fig5_re_by_construction():
    """Hardcoded from archive Section 53: 10 trials each at lambda=0.005, C=8."""
    archs = [
        ('MLP', 10),
        ('Trained Attn', 0),
        ('Fixed Random Attn', 0),
        ('Sparse Hard Attn', 1),
        ('Parallel MLP+Attn', 9),
    ]
    names, re_counts = zip(*archs)
    total = 10

    fig, ax = plt.subplots(figsize=(8, 5))
    widths = [r / total for r in re_counts]
    colors = ['#2166ac' if w >= 0.8 else ('#f4a582' if w >= 0.5 else '#b2182b') for w in widths]

    x = np.arange(len(names))
    ax.bar(x, widths, color=colors, edgecolor='black', linewidth=0.5)
    ax.axhline(0.8, color='green', linestyle='--', alpha=0.5, label='RE threshold (80%)')
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=30, ha='right')
    ax.set_ylabel('P(RE)')
    ax.set_title('RE-by-Construction: Architecture Comparison ($\\lambda=0.005$, $C=8$, 10 trials)')
    ax.set_ylim(0, 1.15)
    ax.legend(loc='upper right')

    for i, (r, t) in enumerate(zip(re_counts, [total] * len(names))):
        ax.text(i, widths[i] + 0.02, f'{r}/{t}', ha='center', fontsize=10, fontweight='bold')

    fig.tight_layout()
    fig.savefig(OUT / 're_by_construction.pdf', bbox_inches='tight')
    plt.close(fig)
    print("  -> re_by_construction.pdf")


# ====================================================================
# FIG 6: Intervention failure summary
# ====================================================================
def fig6_interventions():
    fig, ax = plt.subplots(figsize=(9, 4.5))

    interventions = {
        'L2 (baseline)': ('MLP', '10/10'),
        'L2 + Residual': ('MLP+Res', '10/10'),
        'L2 (baseline)': ('AttnOnly', '0/10'),
        'L2 + Residual': ('Attn+Res', '0/10'),
        'L2 + LN + Res': ('FullHybrid', '0/10'),
        'L2 + Dropout (p=0.1)': ('AttnOnly', '0/5'),
        'L2 + Orthogonal Reg': ('AttnOnly', '0/5'),
        'L2 + Pre-LN': ('Attn+LN', '0/5'),
        'L2 + Post-LN': ('Attn+LN', '0/5'),
    }

    # Group: first 2 succeed (MLP), rest fail (attention)
    labels = list(interventions.keys())
    archs = [v[0] for v in interventions.values()]
    results = [v[1] for v in interventions.values()]
    is_success = [v[1].startswith('10') for v in interventions.values()]

    bar_colors = ['#2166ac' if s else '#b2182b' for s in is_success]
    y = np.arange(len(labels))

    ax.barh(y, [1 if s else 0.05 for s in is_success], color=bar_colors, edgecolor='black', linewidth=0.5, height=0.6)

    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlim(0, 1.1)
    ax.set_xlabel('P(RE)')
    ax.set_title('All Interventions Fail for Attention Architectures')
    ax.set_xticks([0, 0.5, 1.0])
    ax.set_xticklabels(['0', '', '10/10'])

    for i, (arch, res) in enumerate(zip(archs, results)):
        color = 'white' if is_success[i] else 'white'
        xpos = 0.5 if is_success[i] else 0.025
        ax.text(xpos, i, f'{arch}: {res}', ha='center' if is_success[i] else 'left',
                va='center', fontsize=9, color=color, fontweight='bold')

    fig.tight_layout()
    fig.savefig(OUT / 'intervention_failures.pdf', bbox_inches='tight')
    plt.close(fig)
    print("  -> intervention_failures.pdf")


# ====================================================================
# MAIN
# ====================================================================
if __name__ == '__main__':
    print("Generating paper figures...")
    fig1_phase_diagram()
    fig2_ablation()
    fig3_basis_reset()
    fig4_isomorphism()
    fig5_re_by_construction()
    fig6_interventions()
    print("Done.")
